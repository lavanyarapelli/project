﻿using System;

namespace LRC_DAL
{
    public class Class1
    {
    }
}
