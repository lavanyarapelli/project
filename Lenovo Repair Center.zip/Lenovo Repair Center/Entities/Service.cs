﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class Service
    {
        public string ServiceID { get; set; }
        public DateTime RequestDate { get; set; }
        public string OwnerName { get; set; }
        public string ContactNo{ get; set; }
        public string DeviceType { get; set; }
        public string SerialNo { get; set; }
        public string IssueDescription{ get; set; }
    }
}
