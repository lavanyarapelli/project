﻿using LRCExceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using Entities;
using LRC_BAL;
using System.Text.RegularExpressions;

namespace Lenovo_Repair_Center
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            //DatePicker.SelectedDate= DateTime.Today;
        }
        


            private void BtnSubmitRequest_Click(object sender, RoutedEventArgs e)
        {

           
            SubmitRequest();  //both  submit and get request are called
            
        }

        

        private void SubmitRequest()
        {
            try
            {
                Service service = new Service();
                //string serviceid;
                //DateTime date;
                //string ownername;
                //string contactno;
                //string devicetype;
                //string Serialno;
                //string issuedescription;

                if (txtId.Text == string.Empty ||
                    txtRequestDate.Text == string.Empty ||
                    txtName1.Text == string.Empty ||
                    txtName2.Text == string.Empty ||
                    lblSerial.Text == string.Empty ||
                    lblDescription.Text == string.Empty)
                {
                    MessageBox.Show("Please Enter All Fields");
                }
                //
                else
                {
                    bool RequestAdded;

                    service.ServiceID = txtId.Text;
                    service.RequestDate= Convert.ToDateTime(txtRequestDate.Text);
                    service.OwnerName = txtName1.Text;
                    service.ContactNo = txtName2.Text;
                    service.DeviceType = ((ComboBoxItem)cbBlock.SelectedItem).Content.ToString();
                    service.SerialNo= txtName3.Text;
                    service.IssueDescription = txtName4.Text;

                    //

                    //Service ser = new Service   // values are inserted into object and passed to BAL
                    //{
                    //    ServiceID = serviceid,
                    //    RequestDate = date,
                    //    OwnerName = ownername,
                    //    ContactNo = contactno,
                    //    DeviceType = devicetype,
                    //    SerialNo = Serialno,
                    //    IssueDescription = issuedescription
                    //};
                    RequestAdded = lrcbal.SubmitRequest(service);

                    if (RequestAdded == true)
                    {
                        MessageBox.Show("Request  added successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Request couldn't be added.");
                    }
                }
            }

            catch (LrcExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetRequest()   //displays service requests
        {
            try
            {
                List<Service> services= lrcbal.GetAllRequest();
                if (services != null)
                {
                    dgServices.ItemsSource = services;
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (LrcExceptions ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetRequest();
        }

        private void TxtRequestDate_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
